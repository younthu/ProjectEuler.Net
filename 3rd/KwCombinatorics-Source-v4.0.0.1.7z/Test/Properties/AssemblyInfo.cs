﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion ("4.0.0.1")]
[assembly: AssemblyFileVersion ("4.0.0.1")]

[assembly: AssemblyTitle ("KwCombinatorics Test")]
[assembly: AssemblyDescription ("")]
[assembly: AssemblyConfiguration ("")]
[assembly: AssemblyCompany ("Kasewick@gmail.com")]
[assembly: AssemblyProduct ("KwCombinatorics")]
[assembly: AssemblyCopyright ("Copyright © 2009-2012 Kasey Osborn")]
[assembly: AssemblyTrademark ("")]
[assembly: AssemblyCulture ("")]

[assembly: ComVisible (false)]
[assembly: Guid ("a0f2ee75-8ced-4638-a780-fa2cd0c0b706")]

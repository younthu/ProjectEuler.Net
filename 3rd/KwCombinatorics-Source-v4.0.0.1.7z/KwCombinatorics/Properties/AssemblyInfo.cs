﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion ("4.0.0.1")]
[assembly: AssemblyFileVersion ("4.0.0.1")]

[assembly: CLSCompliant (true)]

[assembly: AssemblyTitle ("KwCombinatorics")]
[assembly: AssemblyDescription ("Combinatorics library")]
[assembly: AssemblyConfiguration ("")]
[assembly: AssemblyCompany ("Kasewick@gmail.com")]
[assembly: AssemblyProduct ("KwCombinatorics")]
[assembly: AssemblyCopyright ("Copyright © 2009-2012 Kasey Osborn")]
[assembly: AssemblyTrademark ("")]
[assembly: AssemblyCulture ("")]

[assembly: ComVisible (false)]
[assembly: Guid ("24a4e6fd-ab7b-4231-95f5-1d95e3f0a50c")]
